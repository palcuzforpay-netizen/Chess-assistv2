package bench.chessassist

import android.content.Context
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.util.concurrent.Executors

/** Local Stockfish over UCI. Binary: app/src/main/jniLibs/arm64-v8a/libstockfish.so */
class Engine(private val ctx: Context) {
    private val exec = Executors.newSingleThreadExecutor()
    private var proc: Process? = null
    private lateinit var out: BufferedWriter
    private lateinit var inp: BufferedReader

    private fun ensure() {
        if (proc != null) return
        val bin = File(ctx.applicationInfo.nativeLibraryDir, "libstockfish.so")
        val p = ProcessBuilder(bin.absolutePath).redirectErrorStream(true).start()
        out = p.outputStream.bufferedWriter(); inp = p.inputStream.bufferedReader(); proc = p
        send("uci"); until("uciok")
        send("setoption name Threads value 2")
        send("setoption name Hash value 64")
        send("isready"); until("readyok")
    }

    private fun send(s: String) { out.write(s); out.write("\n"); out.flush() }

    private fun until(tok: String) {
        while (true) {
            val l = inp.readLine() ?: error("engine exited")
            if (l.startsWith(tok)) return
        }
    }

    /** cb(bestMoveUci or null, evalText) — runs on the engine thread. */
    fun search(fen: String, elo: Int, ms: Int, cb: (String?, String) -> Unit) = exec.execute {
        try {
            ensure()
            if (elo >= Prefs.ELO_MAX) {
                send("setoption name UCI_LimitStrength value false")
            } else {
                send("setoption name UCI_LimitStrength value true")
                send("setoption name UCI_Elo value $elo")
            }
            send("position fen $fen")
            send("go movetime $ms")
            var ev = ""
            while (true) {
                val l = inp.readLine() ?: break
                if (l.startsWith("info") && " score " in l) {
                    val t = l.split(" ")
                    val i = t.indexOf("score")
                    if (i >= 0 && i + 2 < t.size) ev = when (t[i + 1]) {
                        "cp" -> String.format("%+.2f", (t[i + 2].toIntOrNull() ?: 0) / 100.0)
                        "mate" -> "M${t[i + 2]}"
                        else -> ev
                    }
                } else if (l.startsWith("bestmove")) {
                    val m = l.split(" ").getOrNull(1)
                    cb(if (m == null || m == "(none)") null else m, ev)
                    return@execute
                }
            }
            cb(null, "")
        } catch (e: Exception) {
            proc?.destroy(); proc = null
            cb(null, "engine error: ${e.message ?: e.javaClass.simpleName}".take(60))
        }
    }

    fun close() {
        runCatching { send("quit") }
        proc?.destroy()
        exec.shutdownNow()
    }
}
