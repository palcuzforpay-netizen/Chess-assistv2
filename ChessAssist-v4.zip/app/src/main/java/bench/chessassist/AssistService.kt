package bench.chessassist

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Captures the screen, reads the board, runs Stockfish, draws the arrow over the chess app.
 * The arrow hides the moment you touch the screen so it never pollutes the next read.
 */
class AssistService : Service() {
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val bgThread = HandlerThread("capture").apply { start() }
    private val bg by lazy { Handler(bgThread.looper) }
    private val main = Handler(Looper.getMainLooper())
    private var frame: Bitmap? = null
    private var sw = 0; private var sh = 0

    private val views = ArrayList<View>()
    private lateinit var arrow: ArrowView
    private lateinit var bar: LinearLayout
    private lateinit var barLp: LP
    private lateinit var statusTv: TextView
    private lateinit var boardBtn: TextView
    private lateinit var debugTv: TextView
    private var selector: FrameSelector? = null

    @Volatile private var boardReader: BoardReader? = null
    @Volatile private var enabled = true
    @Volatile private var arrowShown = false
    @Volatile private var hiddenAt = 0L
    @Volatile private var analyzedFen: String? = null
    @Volatile private var cachedMove: String? = null
    @Volatile private var cachedEval = ""

    private var candidate: String? = null
    private var candCount = 0
    private var stable: Array<CharArray>? = null
    private var stableKey: String? = null
    private var side = 'w'
    private var engine: Engine? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        wm = getSystemService(WindowManager::class.java)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
        }
        setupCapture()
        setupOverlays()
        engine = Engine(this)
        bg.post(loop)
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("assist", "Assist", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "assist")
            .setContentTitle("Chess Assist running")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------------- capture ----------------
    private fun setupCapture() {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds; sw = b.width(); sh = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            sw = dm.widthPixels; sh = dm.heightPixels
        }
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        vd = projection!!.createVirtualDisplay(
            "assist", sw, sh, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, bg
        )
    }

    /** Latest screen frame; reuses the previous one when the screen hasn't changed. */
    private fun grab(): Bitmap? {
        val img = try { reader?.acquireLatestImage() } catch (e: IllegalStateException) { null } ?: return frame
        try {
            val pl = img.planes[0]
            val w = pl.rowStride / pl.pixelStride
            var b = frame
            if (b == null || b.width != w || b.height != img.height) {
                b = Bitmap.createBitmap(w, img.height, Bitmap.Config.ARGB_8888); frame = b
            }
            pl.buffer.rewind()
            b.copyPixelsFromBuffer(pl.buffer)
        } catch (_: RuntimeException) {
        } finally { img.close() }
        return frame
    }

    private val loop = object : Runnable {
        override fun run() {
            try { tick() } catch (e: Exception) { st("error: ${e.javaClass.simpleName}") }
            bg.postDelayed(this, 200)
        }
    }

    private var lastSt = ""
    private fun st(s: String) { if (s != lastSt) { lastSt = s; ui { status(s) } } }
    @Volatile private var debugOn = false
    @Volatile private var thinkStart = 0L

    private fun tick() {
        val bmp = grab()                                     // always drain the reader
        val br = boardReader ?: return
        if (!enabled || arrowShown) return
        if (bmp == null) { st("no screen frames"); return }
        if (System.currentTimeMillis() - hiddenAt < 250) return  // let the arrow-free frame land

        val g = br.read(Pix(bmp))
        if (debugOn) { val txt = Fen.pretty(g); ui { debugTv.text = txt } }
        Fen.problem(g)?.let { st("bad read: $it"); candidate = null; return }
        val key = g.joinToString("/") { String(it) }
        if (key != candidate) { candidate = key; candCount = 1; return }
        if (++candCount < 2) return                          // 2 identical reads = settled

        if (key != stableKey) {
            val prev = stable
            when {
                key == BoardReader.START_KEY -> side = 'w'
                prev != null -> {
                    var mover: Char? = null
                    for (r in 0..7) for (f in 0..7) {
                        val c = g[r][f]
                        if (c != prev[r][f] && c != '.') mover = if (c.isUpperCase()) 'w' else 'b'
                    }
                    if (mover != null) side = if (mover == 'w') 'b' else 'w'
                }
            }
            stable = g; stableKey = key
        }

        val me = if (br.flipped) 'b' else 'w'
        if (side != me) { st("opponent's turn"); return }

        val fen = Fen.of(g, side)
        if (fen == analyzedFen) {
            if (cachedMove != null && System.currentTimeMillis() - hiddenAt > 1500) ui { showArrow() }
            else if (cachedMove == null && System.currentTimeMillis() - thinkStart > Prefs.moveTime(this) + 6000)
                st("engine not answering")
            return
        }
        analyzedFen = fen; cachedMove = null; thinkStart = System.currentTimeMillis()
        st("thinking…")
        engine?.search(fen, Prefs.elo(this), Prefs.moveTime(this)) { mv, ev ->
            main.post {
                if (analyzedFen != fen) return@post
                if (mv == null) { lastSt = ""; status(ev.ifEmpty { "no move" }); return@post }
                cachedMove = mv; cachedEval = ev
                if (enabled) showArrow()
            }
        }
    }

    // ---------------- overlays ----------------
    private val type = LP.TYPE_APPLICATION_OVERLAY

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    private fun setupOverlays() {
        // arrow layer: touches pass through (alpha <= 0.8 required on Android 12+)
        arrow = ArrowView(this).apply { visibility = View.GONE }
        add(arrow, LP(LP.MATCH_PARENT, LP.MATCH_PARENT, type,
            LP.FLAG_NOT_TOUCHABLE or LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; alpha = 0.8f })

        // 1px sentinel: gets ACTION_OUTSIDE on any touch -> hide arrow
        val sentinel = object : View(this) {
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) hideArrow()
                return false
            }
        }
        add(sentinel, LP(1, 1, type,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL or LP.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })

        // control bar
        val dpx = resources.displayMetrics.density
        fun r(c: Int, rad: Float) = android.graphics.drawable.GradientDrawable().apply { setColor(c); cornerRadius = rad * dpx }
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = r(0xE6121318.toInt(), 16f)
            val p = (8 * dpx).toInt(); setPadding(p, p, p, p)
            elevation = 8 * dpx
        }
        fun chip(t: String, fill: Int, onClick: (TextView) -> Unit) = TextView(this).apply {
            text = t; gravity = Gravity.CENTER; textSize = 13f; typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(if (fill == 0xFF00C878.toInt()) Color.BLACK else Color.WHITE)
            background = r(fill, 12f)
            val v = (7 * dpx).toInt(); setPadding(v * 2, v, v * 2, v)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = (6 * dpx).toInt() }
            setOnClickListener { onClick(this) }
        }
        val handle = TextView(this).apply {
            text = "≡  evil rad"; setTextColor(0xFF8A8F9C.toInt()); textSize = 12f
            typeface = android.graphics.Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }
        statusTv = TextView(this).apply {
            setTextColor(0xFF7FFFBF.toInt()); textSize = 12f; text = "tap Board"
            maxWidth = (150 * dpx).toInt(); setPadding(0, (4 * dpx).toInt(), 0, 0)
        }
        debugTv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 10f; typeface = android.graphics.Typeface.MONOSPACE
            visibility = View.GONE
        }
        val boardChip = chip("Board", 0xFF00C878.toInt()) { onBoardBtn() }
        boardChip.setOnLongClickListener { startManual(); true }
        boardBtn = boardChip
        val toggle = chip("On", 0xFF2A2D36.toInt()) { v ->
            enabled = !enabled; v.text = if (enabled) "On" else "Off"
            if (!enabled) { hideArrow(); status("paused") }
            analyzedFen = null
        }
        val debug = chip("Debug", 0xFF2A2D36.toInt()) {
            debugOn = !debugOn
            debugTv.visibility = if (debugOn) View.VISIBLE else View.GONE
        }
        val exit = chip("Exit", 0xFF3A1E22.toInt()) { stopSelf() }
        listOf(handle, statusTv, debugTv, boardChip, toggle, debug, exit).forEach { bar.addView(it) }

        barLp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, type,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 16; y = sh / 10
        }
        var sx = 0; var sy = 0; var rx = 0f; var ry = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = barLp.x; sy = barLp.y; rx = e.rawX; ry = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    barLp.x = sx + (e.rawX - rx).toInt(); barLp.y = sy + (e.rawY - ry).toInt()
                    wm.updateViewLayout(bar, barLp)
                }
            }
            true
        }
        add(bar, barLp)
    }

    private fun add(v: View, lp: LP) { wm.addView(v, lp); views += v }
    private fun remove(v: View) { runCatching { wm.removeView(v) }; views -= v }

    /** Tap Board: find the board automatically. Long-press Board: place it by hand. */
    private fun onBoardBtn() {
        if (selector != null) { lockManual(); return }
        hideArrow(); boardReader = null
        status("finding board…")
        bg.post {
            val bmp = grab()
            if (bmp == null) { ui { status("no screen frames") }; return@post }
            val px = Pix(bmp)
            val rect = BoardReader.find(px)
            finishLock(px, rect)
        }
    }

    private fun startManual() {
        if (selector != null) return
        hideArrow(); boardReader = null
        val s = FrameSelector(this)
        add(s, LP(LP.MATCH_PARENT, LP.MATCH_PARENT, type,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })
        remove(bar); add(bar, barLp)
        selector = s; boardBtn.text = "Lock"
        status("drag square over board")
    }

    private fun lockManual() {
        val sel = selector ?: return
        val rect = sel.screenRect()
        remove(sel); selector = null; boardBtn.text = "Board"
        status("reading…")
        bg.postDelayed({
            val bmp = grab() ?: run { ui { status("no screen frames") }; return@postDelayed }
            val px = Pix(bmp)
            finishLock(px, BoardReader.snap(px, rect))
        }, 400)
    }

    /** bg thread */
    private fun finishLock(px: Pix, rect: Rect) {
        val br = BoardReader.calibrate(px, rect)
        candidate = null; candCount = 0; stable = null; stableKey = null
        side = 'w'; analyzedFen = null; cachedMove = null
        if (br == null) { ui { status("couldn't find board — long-press Board") }; return }
        val check = br.read(px)
        val ok = check.joinToString("/") { String(it) } == BoardReader.START_KEY
        ui {
            // flash the detected grid so you can see it found the right spot
            arrow.gridRect = br.rect; arrow.move = null
            arrow.alpha = 1f; arrow.visibility = View.VISIBLE; arrow.invalidate()
            status(if (!ok) "board found, but not at start pos?" else if (br.flipped) "you: black" else "you: white")
            main.postDelayed({
                arrow.gridRect = null; arrow.visibility = View.GONE
                hiddenAt = System.currentTimeMillis()
                boardReader = br
            }, 1200)
        }
    }

    private fun showArrow() {
        val br = boardReader ?: return
        val mv = cachedMove ?: return
        arrow.gridRect = null
        arrow.board = br.rect; arrow.flipped = br.flipped
        arrow.move = mv; arrow.eval = cachedEval
        arrow.alpha = 0f; arrow.visibility = View.VISIBLE; arrow.invalidate()
        arrow.animate().alpha(1f).setDuration(160).start()
        arrowShown = true
        status("$mv  $cachedEval")
    }

    private fun hideArrow() {
        if (!arrowShown) return
        arrow.animate().cancel(); arrow.visibility = View.GONE
        arrowShown = false
        hiddenAt = System.currentTimeMillis()
    }

    private fun status(s: String) { statusTv.text = s }
    private fun ui(f: () -> Unit) { main.post(f) }

    override fun onDestroy() {
        bg.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) views.toList().forEach { remove(it) }
        vd?.release(); reader?.close()
        projection?.stop(); projection = null
        engine?.close()
        bgThread.quitSafely()
        super.onDestroy()
    }
}
