package bench.chessassist

import android.content.Context

object Prefs {
    // Stockfish 16/17 UCI_Elo range. ELO_MAX = no strength limit.
    const val ELO_MIN = 1320
    const val ELO_MAX = 3190
    const val MS_MIN = 100
    const val MS_MAX = 3000

    private fun sp(c: Context) = c.getSharedPreferences("assist", Context.MODE_PRIVATE)

    fun arrowColor(c: Context) = sp(c).getInt("color", 0xD900C878.toInt())
    fun setArrowColor(c: Context, v: Int) = sp(c).edit().putInt("color", v).apply()

    fun elo(c: Context) = sp(c).getInt("elo", 2000)
    fun setElo(c: Context, v: Int) = sp(c).edit().putInt("elo", v).apply()

    fun moveTime(c: Context) = sp(c).getInt("ms", 800)
    fun setMoveTime(c: Context, v: Int) = sp(c).edit().putInt("ms", v).apply()
}
