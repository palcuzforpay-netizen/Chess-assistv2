package bench.chessassist

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.sqrt

/** Fast pixel access to one captured frame. */
class Pix(bmp: Bitmap) {
    val w = bmp.width
    val h = bmp.height
    private val a = IntArray(w * h).also { bmp.getPixels(it, 0, w, 0, 0, w, h) }
    fun at(x: Int, y: Int): Int = if (x < 0 || y < 0 || x >= w || y >= h) 0 else a[y * w + x]
    fun lum(x: Int, y: Int): Float {
        val p = at(x, y)
        return 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
    }
}

/**
 * Screen-based board recognition.
 * Each square is split into "background" (matches the square's own edge color, so light/dark
 * squares and move highlights all drop out) and "piece" pixels. Pieces are matched by shape +
 * brightness against samples taken from the starting position.
 * Grid convention: grid[rank][file], rank 0 = rank 1, '.' = empty.
 */
class BoardReader private constructor(
    val rect: Rect,
    val flipped: Boolean,                         // true = black at the bottom
    private val tpl: List<Pair<Char, FloatArray>>,
    private val fillMin: Float
) {
    class Feat(val v: FloatArray, val fill: Float, val pieceLum: Float)

    companion object {
        private const val N = 16
        private const val INSET = 0.10f
        private const val BG_DIST = 32f
        private const val CLASSES = "PNBRQKpnbrqk"

        private val START = arrayOf(
            "RNBQKBNR", "PPPPPPPP", "........", "........",
            "........", "........", "pppppppp", "rnbqkbnr"
        )
        val START_KEY = START.joinToString("/")

        fun toBoard(col: Int, row: Int, flipped: Boolean): Pair<Int, Int> =
            if (flipped) (7 - col) to row else col to (7 - row)

        private val BG_PTS = arrayOf(
            0.06f to 0.06f, 0.5f to 0.04f, 0.94f to 0.06f, 0.04f to 0.5f,
            0.96f to 0.5f, 0.06f to 0.94f, 0.5f to 0.97f, 0.94f to 0.94f
        )

        fun feat(px: Pix, r: Rect, col: Int, row: Int): Feat {
            val s = r.width() / 8f
            val x0 = r.left + col * s; val y0 = r.top + row * s
            // square background = per-channel median of edge samples (ignores corner labels)
            val rs = IntArray(BG_PTS.size); val gs = IntArray(BG_PTS.size); val bs = IntArray(BG_PTS.size)
            BG_PTS.forEachIndexed { i, (fx, fy) ->
                val p = px.at((x0 + fx * s).toInt(), (y0 + fy * s).toInt())
                rs[i] = (p shr 16) and 255; gs[i] = (p shr 8) and 255; bs[i] = p and 255
            }
            rs.sort(); gs.sort(); bs.sort()
            val br = (rs[3] + rs[4]) / 2f; val bg = (gs[3] + gs[4]) / 2f; val bb = (bs[3] + bs[4]) / 2f

            val v = FloatArray(2 * N * N)
            val span = 1f - 2 * INSET
            var on = 0; var lumSum = 0f
            for (j in 0 until N) for (i in 0 until N) {
                val x = (x0 + (INSET + span * (i + 0.5f) / N) * s).toInt()
                val y = (y0 + (INSET + span * (j + 0.5f) / N) * s).toInt()
                val p = px.at(x, y)
                val pr = (p shr 16) and 255; val pg = (p shr 8) and 255; val pb = p and 255
                val d = sqrt((pr - br) * (pr - br) + (pg - bg) * (pg - bg) + (pb - bb) * (pb - bb))
                if (d > BG_DIST) {
                    val l = (0.299f * pr + 0.587f * pg + 0.114f * pb) / 255f
                    v[j * N + i] = 1f
                    v[N * N + j * N + i] = l
                    on++; lumSum += l
                }
            }
            val fill = on / (N * N).toFloat()
            return Feat(v, fill, if (on > 0) lumSum / on else 0f)
        }

        // ---------- board location ----------

        /** How much a candidate grid looks like the empty middle of a starting board. */
        private fun score(px: Pix, l: Float, t: Float, size: Float): Float {
            val q = size / 8f
            var light = 0f; var dark = 0f; var varSum = 0f
            for (row in 2..5) for (col in 0..7) {
                var sum = 0f; var sq = 0f
                for (j in 0 until 5) for (i in 0 until 5) {
                    val v = px.lum(
                        (l + (col + 0.06f + 0.88f * (i + 0.5f) / 5) * q).toInt(),
                        (t + (row + 0.06f + 0.88f * (j + 0.5f) / 5) * q).toInt()
                    )
                    sum += v; sq += v * v
                }
                val m = sum / 25f
                varSum += (sq / 25f - m * m).coerceAtLeast(0f)
                if ((row + col) % 2 == 0) light += m else dark += m
            }
            return abs(light - dark) / 16f - 0.6f * sqrt(varSum / 32f)
        }

        /** Fine-tune a rough rectangle onto the real board. */
        fun snap(px: Pix, r: Rect): Rect {
            var bl = r.left.toFloat(); var bt = r.top.toFloat(); var bs = r.width().toFloat()
            var best = score(px, bl, bt, bs)
            for (step in floatArrayOf(0.04f, 0.04f, 0.015f, 0.015f, 0.005f, 0.005f)) {
                val cl = bl; val ct = bt; val cs = bs
                for (ds in -3..3) for (dx in -3..3) for (dy in -3..3) {
                    val size = cs * (1 + ds * step * 0.5f)
                    val l = cl + dx * step * cs; val t = ct + dy * step * cs
                    val sc = score(px, l, t, size)
                    if (sc > best) { best = sc; bl = l; bt = t; bs = size }
                }
            }
            return Rect(bl.toInt(), bt.toInt(), (bl + bs).toInt(), (bt + bs).toInt())
        }

        /** Find the board anywhere on screen (game must be at the start position). */
        fun find(px: Pix): Rect {
            val sw = px.w.toFloat()
            var best = Float.NEGATIVE_INFINITY
            var bl = 0f; var bt = 0f; var bs = sw
            var frac = 0.70f
            while (frac <= 1.001f) {
                val size = sw * frac
                val step = size * 0.02f
                var t = 0f
                while (t + size <= px.h) {
                    for (dx in -2..2) {
                        val l = (sw - size) / 2f + dx * step
                        val sc = score(px, l, t, size)
                        if (sc > best) { best = sc; bl = l; bt = t; bs = size }
                    }
                    t += step
                }
                frac += 0.025f
            }
            return snap(px, Rect(bl.toInt(), bt.toInt(), (bl + bs).toInt(), (bt + bs).toInt()))
        }

        // ---------- calibration ----------

        /** Board must be showing the starting position. */
        fun calibrate(px: Pix, r: Rect): BoardReader? {
            if (r.width() < 80) return null
            // white pieces are brighter than black ones
            var bottom = 0f; var top = 0f
            for (c in 0..7) { bottom += feat(px, r, c, 7).pieceLum; top += feat(px, r, c, 0).pieceLum }
            val flipped = bottom < top

            val tpl = ArrayList<Pair<Char, FloatArray>>()
            var eMax = 0f; var pMin = 1f
            for (row in 0..7) for (col in 0..7) {
                val (f, rk) = toBoard(col, row, flipped)
                val ch = START[rk][f]
                val ft = feat(px, r, col, row)
                if (ch == '.') eMax = maxOf(eMax, ft.fill)
                else { pMin = minOf(pMin, ft.fill); tpl += ch to ft.v }
            }
            val th = if (pMin > eMax) (eMax + pMin) / 2f else (eMax + 0.02f)
            return BoardReader(Rect(r), flipped, tpl, th.coerceIn(0.02f, 0.2f))
        }
    }

    fun read(px: Pix): Array<CharArray> {
        val g = Array(8) { CharArray(8) { '.' } }
        val dist = HashMap<Int, FloatArray>()            // square -> distance per class
        for (row in 0..7) for (col in 0..7) {
            val ft = feat(px, rect, col, row)
            if (ft.fill < fillMin) continue
            val d = FloatArray(12) { Float.MAX_VALUE }
            for ((ch, t) in tpl) {
                var s = 0f
                for (k in t.indices) { val e = t[k] - ft.v[k]; s += e * e }
                val ci = CLASSES.indexOf(ch)
                if (s < d[ci]) d[ci] = s
            }
            val (f, rk) = toBoard(col, row, flipped)
            g[rk][f] = CLASSES[argmin(d, null)]
            dist[rk * 8 + f] = d
        }
        repair(g, dist)
        return g
    }

    private fun argmin(d: FloatArray, exclude: Set<Int>?): Int {
        var bi = 0; var bv = Float.MAX_VALUE
        for (i in d.indices) if ((exclude == null || i !in exclude) && d[i] < bv) { bv = d[i]; bi = i }
        return bi
    }

    /** Use chess rules to fix likely misreads: exactly one king per side, no pawns on rank 1/8. */
    private fun repair(g: Array<CharArray>, dist: Map<Int, FloatArray>) {
        for (white in listOf(true, false)) {
            val kc = if (white) 'K' else 'k'
            val ki = CLASSES.indexOf(kc)
            val pi = CLASSES.indexOf(if (white) 'P' else 'p')
            val mine = dist.keys.filter { val c = g[it / 8][it % 8]; c != '.' && c.isUpperCase() == white }
            val kings = mine.filter { g[it / 8][it % 8] == kc }
            if (kings.isEmpty() && mine.isNotEmpty()) {
                val sq = mine.minBy { val d = dist[it]!!; d[ki] - d[CLASSES.indexOf(g[it / 8][it % 8])] }
                g[sq / 8][sq % 8] = kc
            } else if (kings.size > 1) {
                val keep = kings.minBy { dist[it]!![ki] }
                val sideIdx = if (white) (0..5).toSet() else (6..11).toSet()
                for (sq in kings) if (sq != keep) {
                    val ex = (0..11).toSet() - sideIdx + ki
                    g[sq / 8][sq % 8] = CLASSES[argmin(dist[sq]!!, ex)]
                }
            }
            for (sq in mine) {
                val rk = sq / 8
                if ((rk == 0 || rk == 7) && g[rk][sq % 8] == CLASSES[pi]) {
                    val sideIdx = if (white) (0..5).toSet() else (6..11).toSet()
                    g[rk][sq % 8] = CLASSES[argmin(dist[sq]!!, (0..11).toSet() - sideIdx + pi + ki)]
                }
            }
        }
    }
}

object Fen {
    fun of(g: Array<CharArray>, side: Char): String {
        val rows = (7 downTo 0).map { r ->
            val sb = StringBuilder(); var run = 0
            for (f in 0..7) {
                val c = g[r][f]
                if (c == '.') { run++; continue }
                if (run > 0) { sb.append(run); run = 0 }
                sb.append(c)
            }
            if (run > 0) sb.append(run)
            sb.toString()
        }
        var cr = ""
        if (g[0][4] == 'K') { if (g[0][7] == 'R') cr += "K"; if (g[0][0] == 'R') cr += "Q" }
        if (g[7][4] == 'k') { if (g[7][7] == 'r') cr += "k"; if (g[7][0] == 'r') cr += "q" }
        return "${rows.joinToString("/")} $side ${cr.ifEmpty { "-" }} - 0 1"
    }

    fun sane(g: Array<CharArray>): Boolean = problem(g) == null

    fun problem(g: Array<CharArray>): String? {
        var wk = 0; var bk = 0
        for (r in 0..7) for (f in 0..7) {
            val c = g[r][f]
            if (c == 'K') wk++; if (c == 'k') bk++
            if ((r == 0 || r == 7) && (c == 'P' || c == 'p')) return "pawn on last rank"
        }
        if (wk != 1) return "white kings: $wk"
        if (bk != 1) return "black kings: $bk"
        return null
    }

    fun pretty(g: Array<CharArray>): String =
        (7 downTo 0).joinToString("\n") { r -> String(g[r]).toList().joinToString(" ") }
}
