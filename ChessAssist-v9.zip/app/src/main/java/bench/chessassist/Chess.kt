package bench.chessassist

/**
 * Small legal-move chess model. The app follows the game move by move: it only has to see
 * which squares are empty / white / black, then works out which legal move explains the change.
 * Squares: index = rank * 8 + file (a1 = 0, h8 = 63).
 */
class Move(val from: Int, val to: Int, val promo: Char = ' ') {
    fun uci(): String {
        fun sq(i: Int) = "${'a' + i % 8}${'1' + i / 8}"
        return sq(from) + sq(to) + (if (promo != ' ') promo.lowercaseChar().toString() else "")
    }
}

class Pos(
    val b: CharArray,
    val white: Boolean,
    val wk: Boolean, val wq: Boolean, val bk: Boolean, val bq: Boolean,
    val ep: Int
) {
    companion object {
        fun start(): Pos {
            val rows = arrayOf("RNBQKBNR", "PPPPPPPP", "........", "........",
                "........", "........", "pppppppp", "rnbqkbnr")
            val b = CharArray(64) { rows[it / 8][it % 8] }
            return Pos(b, true, true, true, true, true, -1)
        }

        private val KN = intArrayOf(1, 2, 2, 1, -1, 2, -2, 1, 1, -2, 2, -1, -1, -2, -2, -1)
        private val KG = intArrayOf(1, 0, -1, 0, 0, 1, 0, -1, 1, 1, 1, -1, -1, 1, -1, -1)
        private val RD = intArrayOf(1, 0, -1, 0, 0, 1, 0, -1)
        private val BD = intArrayOf(1, 1, 1, -1, -1, 1, -1, -1)
    }

    private fun isW(c: Char) = c in 'A'..'Z'
    private fun mine(c: Char, w: Boolean) = c != '.' && isW(c) == w

    /** 0 empty, 1 white, 2 black */
    fun occ(): IntArray = IntArray(64) { val c = b[it]; if (c == '.') 0 else if (isW(c)) 1 else 2 }

    fun attacked(sq: Int, byWhite: Boolean): Boolean {
        val r = sq / 8; val f = sq % 8
        fun at(rr: Int, ff: Int): Char = if (rr in 0..7 && ff in 0..7) b[rr * 8 + ff] else '#'
        fun p(c: Char) = if (byWhite) c.uppercaseChar() else c
        val pr = if (byWhite) r - 1 else r + 1
        if (at(pr, f - 1) == p('p') || at(pr, f + 1) == p('p')) return true
        for (i in 0 until 16 step 2) if (at(r + KN[i], f + KN[i + 1]) == p('n')) return true
        for (i in 0 until 16 step 2) if (at(r + KG[i], f + KG[i + 1]) == p('k')) return true
        for ((dirs, a) in listOf(RD to p('r'), BD to p('b'))) {
            for (i in dirs.indices step 2) {
                var rr = r + dirs[i]; var ff = f + dirs[i + 1]
                while (true) {
                    val c = at(rr, ff)
                    if (c == '#') break
                    if (c != '.') { if (c == a || c == p('q')) return true; break }
                    rr += dirs[i]; ff += dirs[i + 1]
                }
            }
        }
        return false
    }

    fun inCheck(w: Boolean): Boolean {
        val k = if (w) 'K' else 'k'
        val i = b.indexOf(k)
        return i >= 0 && attacked(i, !w)
    }

    private fun pseudo(): List<Move> {
        val out = ArrayList<Move>()
        val w = white
        for (sq in 0 until 64) {
            val c = b[sq]
            if (!mine(c, w)) continue
            val r = sq / 8; val f = sq % 8
            fun add(rr: Int, ff: Int, captureOnly: Boolean = false, quietOnly: Boolean = false): Boolean {
                if (rr !in 0..7 || ff !in 0..7) return false
                val t = rr * 8 + ff; val tc = b[t]
                if (tc != '.' && mine(tc, w)) return false
                if (captureOnly && tc == '.') return false
                if (quietOnly && tc != '.') return false
                out += Move(sq, t)
                return tc == '.'
            }
            when (c.lowercaseChar()) {
                'p' -> {
                    val dir = if (w) 1 else -1
                    val startRank = if (w) 1 else 6
                    val lastRank = if (w) 7 else 0
                    val targets = ArrayList<Int>()
                    val one = (r + dir) * 8 + f
                    if (r + dir in 0..7 && b[one] == '.') {
                        targets += one
                        val two = (r + 2 * dir) * 8 + f
                        if (r == startRank && b[two] == '.') targets += two
                    }
                    for (df in intArrayOf(-1, 1)) {
                        val ff = f + df; val rr = r + dir
                        if (ff !in 0..7 || rr !in 0..7) continue
                        val t = rr * 8 + ff
                        if ((b[t] != '.' && !mine(b[t], w)) || t == ep) targets += t
                    }
                    for (t in targets) {
                        if (t / 8 == lastRank) for (pc in "QRBN") out += Move(sq, t, if (w) pc else pc.lowercaseChar())
                        else out += Move(sq, t)
                    }
                }
                'n' -> for (i in 0 until 16 step 2) add(r + KN[i], f + KN[i + 1])
                'k' -> {
                    for (i in 0 until 16 step 2) add(r + KG[i], f + KG[i + 1])
                    val home = if (w) 4 else 60
                    if (sq == home && !attacked(home, !w)) {
                        val ks = if (w) wk else bk; val qs = if (w) wq else bq
                        if (ks && b[home + 1] == '.' && b[home + 2] == '.' &&
                            b[home + 3] == (if (w) 'R' else 'r') && !attacked(home + 1, !w)) out += Move(home, home + 2)
                        if (qs && b[home - 1] == '.' && b[home - 2] == '.' && b[home - 3] == '.' &&
                            b[home - 4] == (if (w) 'R' else 'r') && !attacked(home - 1, !w)) out += Move(home, home - 2)
                    }
                }
                else -> {
                    val lc = c.lowercaseChar()
                    val dirs = ArrayList<Int>()
                    if (lc == 'r' || lc == 'q') dirs.addAll(RD.toList())
                    if (lc == 'b' || lc == 'q') dirs.addAll(BD.toList())
                    for (i in dirs.indices step 2) {
                        var rr = r + dirs[i]; var ff = f + dirs[i + 1]
                        while (add(rr, ff)) { rr += dirs[i]; ff += dirs[i + 1] }
                    }
                }
            }
        }
        return out
    }

    fun legal(): List<Move> = pseudo().filter { !play(it).inCheck(white) }

    fun play(m: Move): Pos {
        val nb = b.copyOf()
        val c = nb[m.from]
        val lc = c.lowercaseChar()
        nb[m.to] = if (m.promo != ' ') m.promo else c
        nb[m.from] = '.'
        if (lc == 'p' && m.to == ep) nb[m.to + if (white) -8 else 8] = '.'
        if (lc == 'k' && kotlin.math.abs(m.to - m.from) == 2) {
            if (m.to > m.from) { nb[m.from + 1] = nb[m.from + 3]; nb[m.from + 3] = '.' }
            else { nb[m.from - 1] = nb[m.from - 4]; nb[m.from - 4] = '.' }
        }
        var wk2 = wk; var wq2 = wq; var bk2 = bk; var bq2 = bq
        if (c == 'K') { wk2 = false; wq2 = false }
        if (c == 'k') { bk2 = false; bq2 = false }
        for (sq in intArrayOf(m.from, m.to)) when (sq) {
            0 -> wq2 = false; 7 -> wk2 = false; 56 -> bq2 = false; 63 -> bk2 = false
        }
        val nep = if (lc == 'p' && kotlin.math.abs(m.to - m.from) == 16) (m.from + m.to) / 2 else -1
        return Pos(nb, !white, wk2, wq2, bk2, bq2, nep)
    }

    fun fen(): String {
        val rows = (7 downTo 0).map { r ->
            val sb = StringBuilder(); var run = 0
            for (f in 0..7) {
                val c = b[r * 8 + f]
                if (c == '.') { run++; continue }
                if (run > 0) { sb.append(run); run = 0 }
                sb.append(c)
            }
            if (run > 0) sb.append(run)
            sb.toString()
        }
        var cr = (if (wk) "K" else "") + (if (wq) "Q" else "") + (if (bk) "k" else "") + (if (bq) "q" else "")
        if (cr.isEmpty()) cr = "-"
        val eps = if (ep >= 0) "${'a' + ep % 8}${'1' + ep / 8}" else "-"
        return "${rows.joinToString("/")} ${if (white) "w" else "b"} $cr $eps 0 1"
    }

    fun pretty(): String = (7 downTo 0).joinToString("\n") { r ->
        (0..7).joinToString(" ") { f -> b[r * 8 + f].toString() }
    }
}

object Tracker {
    /** Squares that differ; -1 in `b` (hidden) never counts. */
    fun mismatch(a: IntArray, b: IntArray): Int { var n = 0; for (i in a.indices) if (b[i] >= 0 && a[i] != b[i]) n++; return n }

    /**
     * Find the position (current, or after 1-2 legal moves) that matches what's on screen.
     * Returns null if nothing fits — usually a piece mid-drag or mid-animation.
     */
    fun follow(cur: Pos, seen: IntArray): Pos? {
        if (mismatch(cur.occ(), seen) == 0) return cur
        var best: Pos? = null; var bestN = 99; var secondN = 99; var bestOcc: IntArray? = null
        fun consider(p: Pos) {
            val o = p.occ()
            val n = mismatch(o, seen)
            if (n < bestN) {
                // a different-looking candidate pushed down to second place
                if (bestOcc == null || mismatch(bestOcc!!, o) != 0) secondN = bestN
                bestN = n; best = p; bestOcc = o
            } else if (n < secondN && mismatch(bestOcc!!, o) != 0) secondN = n
        }
        val one = cur.legal()
        for (m in one) consider(cur.play(m))
        if (bestN > 0) for (m in one) {           // missed a move? try two plies
            val p1 = cur.play(m)
            for (m2 in p1.legal()) consider(p1.play(m2))
        }
        // exact match, or 1 odd square when nothing else comes close
        return if (bestN == 0 || (bestN == 1 && secondN >= 3)) best else null
    }

    fun prettyOcc(o: IntArray): String = (7 downTo 0).joinToString("\n") { r ->
        (0..7).joinToString(" ") { f -> when (o[r * 8 + f]) { 1 -> "W"; 2 -> "b"; -1 -> "#"; else -> "." } }
    }
}
