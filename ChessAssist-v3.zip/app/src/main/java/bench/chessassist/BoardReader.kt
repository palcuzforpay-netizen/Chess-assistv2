package bench.chessassist

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.sqrt

/**
 * Screen-based board recognition.
 * Calibrated once on the starting position: every piece's look is sampled from the live
 * screen, so it adapts to whatever board theme / piece set the app uses.
 * Grid convention: grid[rank][file], rank 0 = rank 1, '.' = empty.
 */
class BoardReader private constructor(
    val rect: Rect,
    val flipped: Boolean,                 // true = black at the bottom
    private val tpl: List<Pair<Char, FloatArray>>,
    private val emptyStd: Float
) {
    class Feat(val v: FloatArray, val mean: Float, val std: Float)

    companion object {
        private const val N = 12          // samples per side per square
        private const val INSET = 0.18f   // skip square edges (coordinate labels, borders)

        private val START = arrayOf(
            "RNBQKBNR", "PPPPPPPP", "........", "........",
            "........", "........", "pppppppp", "rnbqkbnr"
        )
        val START_KEY = START.joinToString("/")

        fun toBoard(col: Int, row: Int, flipped: Boolean): Pair<Int, Int> =
            if (flipped) (7 - col) to row else col to (7 - row)

        fun feat(bmp: Bitmap, r: Rect, col: Int, row: Int): Feat {
            val s = r.width() / 8f
            val span = 1f - 2 * INSET
            val v = FloatArray(N * N)
            var sum = 0f
            for (j in 0 until N) for (i in 0 until N) {
                val x = (r.left + (col + INSET + span * (i + 0.5f) / N) * s).toInt().coerceIn(0, bmp.width - 1)
                val y = (r.top + (row + INSET + span * (j + 0.5f) / N) * s).toInt().coerceIn(0, bmp.height - 1)
                val p = bmp.getPixel(x, y)
                val l = 0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)
                v[j * N + i] = l; sum += l
            }
            val mean = sum / v.size
            var sq = 0f
            for (k in v.indices) { v[k] -= mean; sq += v[k] * v[k] }
            val std = sqrt(sq / v.size)
            if (std > 1e-3f) for (k in v.indices) v[k] /= std   // normalize: survives move highlights
            return Feat(v, mean, std)
        }

        /**
         * Auto-align: start from the user's rough square and search position/size so the
         * 32 empty middle squares (start position) are as flat and as checkered as possible.
         */
        fun snap(bmp: Bitmap, r: Rect): Rect {
            val w = bmp.width; val h = bmp.height
            val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
            fun lum(x: Int, y: Int): Float {
                if (x < 0 || y < 0 || x >= w || y >= h) return 0f
                val p = px[y * w + x]
                return 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
            }
            fun score(l: Float, t: Float, size: Float): Float {
                val q = size / 8f
                var light = 0f; var dark = 0f; var varSum = 0f
                for (row in 2..5) for (col in 0..7) {
                    var sum = 0f; var sq = 0f
                    for (j in 0 until 5) for (i in 0 until 5) {
                        val v = lum(
                            (l + (col + 0.06f + 0.88f * (i + 0.5f) / 5) * q).toInt(),
                            (t + (row + 0.06f + 0.88f * (j + 0.5f) / 5) * q).toInt()
                        )
                        sum += v; sq += v * v
                    }
                    val m = sum / 25f
                    varSum += (sq / 25f - m * m).coerceAtLeast(0f)
                    if ((row + col) % 2 == 0) light += m else dark += m
                }
                return kotlin.math.abs(light - dark) / 16f - 0.6f * sqrt(varSum / 32f)
            }
            var bl = r.left.toFloat(); var bt = r.top.toFloat(); var bs = r.width().toFloat()
            var best = score(bl, bt, bs)
            for (step in floatArrayOf(0.04f, 0.04f, 0.015f, 0.015f, 0.005f)) {
                val cl = bl; val ct = bt; val cs = bs
                for (ds in -3..3) for (dx in -3..3) for (dy in -3..3) {
                    val size = cs * (1 + ds * step * 0.5f)
                    val l = cl + dx * step * cs; val t = ct + dy * step * cs
                    val sc = score(l, t, size)
                    if (sc > best) { best = sc; bl = l; bt = t; bs = size }
                }
            }
            return Rect(bl.toInt(), bt.toInt(), (bl + bs).toInt(), (bt + bs).toInt())
        }

        /** Board must be showing the starting position. */
        fun calibrate(bmp: Bitmap, r: Rect): BoardReader? {
            if (r.width() < 80) return null
            // Bottom and top rows have identical square-color mix, so the brightness gap is the pieces.
            var bottom = 0f; var top = 0f
            for (c in 0..7) { bottom += feat(bmp, r, c, 7).mean; top += feat(bmp, r, c, 0).mean }
            val flipped = bottom < top

            val tpl = ArrayList<Pair<Char, FloatArray>>()
            val empties = ArrayList<Float>(); val pieces = ArrayList<Float>()
            for (row in 0..7) for (col in 0..7) {
                val (f, rk) = toBoard(col, row, flipped)
                val ch = START[rk][f]
                val ft = feat(bmp, r, col, row)
                if (ch == '.') empties += ft.std else { pieces += ft.std; tpl += ch to ft.v }
            }
            val eMax = empties.max(); val pMin = pieces.min()
            val th = if (pMin > eMax) (eMax + pMin) / 2f else eMax * 1.5f
            return BoardReader(Rect(r), flipped, tpl, th)
        }
    }

    fun read(bmp: Bitmap): Array<CharArray> {
        val g = Array(8) { CharArray(8) { '.' } }
        for (row in 0..7) for (col in 0..7) {
            val ft = feat(bmp, rect, col, row)
            if (ft.std < emptyStd) continue
            var best = '.'; var bd = Float.MAX_VALUE
            for ((ch, t) in tpl) {
                var d = 0f
                for (k in t.indices) { val e = t[k] - ft.v[k]; d += e * e }
                if (d < bd) { bd = d; best = ch }
            }
            val (f, rk) = toBoard(col, row, flipped)
            g[rk][f] = best
        }
        return g
    }
}

object Fen {
    fun of(g: Array<CharArray>, side: Char): String {
        val rows = (7 downTo 0).map { r ->
            val sb = StringBuilder(); var run = 0
            for (f in 0..7) {
                val c = g[r][f]
                if (c == '.') { run++; continue }
                if (run > 0) { sb.append(run); run = 0 }
                sb.append(c)
            }
            if (run > 0) sb.append(run)
            sb.toString()
        }
        // Castling inferred from home squares; real rights aren't visible on screen.
        var cr = ""
        if (g[0][4] == 'K') { if (g[0][7] == 'R') cr += "K"; if (g[0][0] == 'R') cr += "Q" }
        if (g[7][4] == 'k') { if (g[7][7] == 'r') cr += "k"; if (g[7][0] == 'r') cr += "q" }
        return "${rows.joinToString("/")} $side ${cr.ifEmpty { "-" }} - 0 1"
    }

    fun sane(g: Array<CharArray>): Boolean = problem(g) == null

    /** null if the position looks legal, otherwise a short reason. */
    fun problem(g: Array<CharArray>): String? {
        var wk = 0; var bk = 0
        for (r in 0..7) for (f in 0..7) {
            val c = g[r][f]
            if (c == 'K') wk++; if (c == 'k') bk++
            if ((r == 0 || r == 7) && (c == 'P' || c == 'p')) return "pawn on last rank"
        }
        if (wk != 1) return "white kings: $wk"
        if (bk != 1) return "black kings: $bk"
        return null
    }

    /** Text mini-board for the debug panel, white at the bottom. */
    fun pretty(g: Array<CharArray>): String =
        (7 downTo 0).joinToString("\n") { r -> String(g[r]).toList().joinToString(" ") }
}
