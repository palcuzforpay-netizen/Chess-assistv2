package bench.chessassist

import android.annotation.SuppressLint
import android.app.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Captures the screen, reads the board, runs Stockfish, draws the arrow over the chess app.
 *
 * The arrow stays up. While it is shown the board is watched with the arrow's area masked out;
 * when anything on the board changes, the arrow is dropped for a moment, the board is read
 * cleanly, and the new best move is drawn.
 */
class AssistService : Service() {
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val bgThread = HandlerThread("capture").apply { start() }
    private val bg by lazy { Handler(bgThread.looper) }
    private val main = Handler(Looper.getMainLooper())
    private var frame: Bitmap? = null
    private var sw = 0; private var sh = 0

    private val views = ArrayList<View>()
    private lateinit var arrow: ArrowView
    private lateinit var bar: LinearLayout
    private lateinit var barLp: LP
    private lateinit var statusTv: TextView
    private lateinit var debugTv: TextView
    private lateinit var boardBtn: TextView
    private lateinit var sideBtn: TextView
    private var selector: FrameSelector? = null

    private enum class Mode { CLEAN, WATCH }

    @Volatile private var boardReader: BoardReader? = null
    @Volatile private var enabled = true
    @Volatile private var mode = Mode.CLEAN
    @Volatile private var cleanAfter = 0L
    @Volatile private var mask: ArrowMask? = null
    @Volatile private var analyzedFen: String? = null
    @Volatile private var cachedMove: String? = null
    @Volatile private var cachedEval = ""
    @Volatile private var thinkStart = 0L
    @Volatile private var debugOn = false

    private var lastSig: FloatArray? = null
    private var candidate: String? = null
    private var candCount = 0
    private var engine: Engine? = null

    // debug info
    private var reads = 0
    private var lastSeen: IntArray? = null
    @Volatile private var pos = Pos.start()
    private val START_OCC = Pos.start().occ()
    private var lastFen = ""
    private var lastEngine = ""
    private var lastMsg = ""

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        wm = getSystemService(WindowManager::class.java)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
        }
        setupCapture()
        setupOverlays()
        engine = Engine(this)
        bg.post(loop)
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("assist", "Assist", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "assist")
            .setContentTitle("evil rad is watching")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------------- capture ----------------
    private fun setupCapture() {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds; sw = b.width(); sh = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            sw = dm.widthPixels; sh = dm.heightPixels
        }
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        vd = projection!!.createVirtualDisplay(
            "assist", sw, sh, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, bg
        )
    }

    /** Latest screen frame; reuses the previous one when the screen hasn't changed. */
    private fun grab(): Bitmap? {
        val img = try { reader?.acquireLatestImage() } catch (e: IllegalStateException) { null } ?: return frame
        try {
            val pl = img.planes[0]
            val w = pl.rowStride / pl.pixelStride
            var b = frame
            if (b == null || b.width != w || b.height != img.height) {
                b = Bitmap.createBitmap(w, img.height, Bitmap.Config.ARGB_8888); frame = b
            }
            pl.buffer.rewind()
            b.copyPixelsFromBuffer(pl.buffer)
        } catch (_: RuntimeException) {
        } finally { img.close() }
        return frame
    }

    private val loop = object : Runnable {
        override fun run() {
            // Throwable, not Exception: an OutOfMemoryError used to kill this loop for good
            try { tick() } catch (e: Throwable) { lastMsg = e.toString(); System.gc() }
            if (debugOn) pushDebug()
            bg.postDelayed(this, 150)
        }
    }

    // ---------------- main loop ----------------
    private fun mySide(br: BoardReader): Char = when (Prefs.side(this)) {
        1 -> 'w'; 2 -> 'b'; else -> if (br.flipped) 'b' else 'w'
    }

    /** Average brightness per square, skipping what the arrow covers. -1 = fully covered. */
    private fun signature(px: Pix, r: Rect, m: ArrowMask?): FloatArray {
        val s = r.width() / 8f
        val out = FloatArray(64)
        for (row in 0..7) for (col in 0..7) {
            var sum = 0f; var n = 0
            for (j in 0 until 5) for (i in 0 until 5) {
                val x = r.left + (col + 0.1f + 0.8f * (i + 0.5f) / 5) * s
                val y = r.top + (row + 0.1f + 0.8f * (j + 0.5f) / 5) * s
                if (m != null && m.hits(x, y)) continue
                sum += px.lum(x.toInt(), y.toInt()); n++
            }
            out[row * 8 + col] = if (n >= 4) sum / n else -1f
        }
        return out
    }

    private fun changed(a: FloatArray, b: FloatArray): Boolean {
        for (i in a.indices) if (a[i] >= 0 && b[i] >= 0 && abs(a[i] - b[i]) > 10f) return true
        return false
    }

    private fun tick() {
        val bmp = grab()
        val br = boardReader ?: return
        if (!enabled) return
        if (bmp == null) { lastMsg = "no screen frames"; return }
        val px = Pix(bmp, br.rect)
        reads++
        val now = System.currentTimeMillis()

        if (mode == Mode.WATCH) {
            // arrow is up: just watch the board around it
            val sig = signature(px, br.rect, mask)
            val prev = lastSig
            lastSig = sig
            if (prev != null && changed(prev, sig)) {
                lastSig = null; candidate = null
                mode = Mode.CLEAN; cleanAfter = now + 150
                ui { dropArrow() }
            }
            return
        }

        if (now < cleanAfter) return                       // wait for the arrow-free frame
        val seen = br.occupancy(px)
        lastSeen = seen
        val key = seen.joinToString("")
        if (key != candidate) { candidate = key; candCount = 1; return }
        if (++candCount < 2) return                        // 2 identical reads = settled

        // new game on screen -> start over
        if (seen.contentEquals(START_OCC) && !pos.b.contentEquals(Pos.start().b)) {
            pos = Pos.start(); analyzedFen = null; cachedMove = null
        }
        val next = Tracker.follow(pos, seen)
        if (next == null) { lastMsg = "board doesn't match a legal move (yet)"; return }
        pos = next
        val fen = pos.fen()
        lastFen = fen

        val myTurn = pos.white == (mySide(br) == 'w')
        if (!myTurn) {                                     // their move: nothing to show
            cachedMove = null; analyzedFen = null
            ui { dropArrow(); lastSt = ""; status("watching…") }
            return
        }

        if (fen == analyzedFen) {
            if (cachedMove != null) ui { showArrow() }
            else if (now - thinkStart > Prefs.moveTime(this) + 6000) { analyzedFen = null; lastMsg = "engine timeout, retrying" }
            return
        }
        analyzedFen = fen; cachedMove = null; thinkStart = now
        st("thinking…")
        engine?.search(fen, Prefs.elo(this), Prefs.moveTime(this)) { mv, ev ->
            lastEngine = if (mv != null) "$mv $ev (${System.currentTimeMillis() - thinkStart}ms)" else "none: $ev"
            main.post {
                if (analyzedFen != fen) return@post
                if (mv == null) { lastMsg = "engine: ${ev.ifEmpty { "no move" }}"; return@post }
                cachedMove = mv; cachedEval = ev
                if (enabled) showArrow()
            }
        }
    }

    // ---------------- overlays ----------------
    private val type = LP.TYPE_APPLICATION_OVERLAY
    private val dpx by lazy { resources.displayMetrics.density }
    private fun r(c: Int, rad: Float) = GradientDrawable().apply { setColor(c); cornerRadius = rad * dpx }

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    private fun setupOverlays() {
        // arrow layer: touches pass through (alpha <= 0.8 required on Android 12+)
        arrow = ArrowView(this).apply { visibility = View.GONE }
        add(arrow, LP(LP.MATCH_PARENT, LP.MATCH_PARENT, type,
            LP.FLAG_NOT_TOUCHABLE or LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; alpha = 0.8f })

        bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = r(0xE6121318.toInt(), 16f)
            val p = (8 * dpx).toInt(); setPadding(p, p, p, p)
            elevation = 8 * dpx
        }
        fun chip(t: String, fill: Int, onClick: (TextView) -> Unit) = TextView(this).apply {
            text = t; gravity = Gravity.CENTER; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (fill == 0xFF00C878.toInt()) Color.BLACK else Color.WHITE)
            background = r(fill, 12f)
            val v = (7 * dpx).toInt(); setPadding(v * 2, v, v * 2, v)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = (6 * dpx).toInt() }
            setOnClickListener { onClick(this) }
        }
        val handle = TextView(this).apply {
            text = "≡  evil rad"; setTextColor(0xFF8A8F9C.toInt()); textSize = 12f
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }
        statusTv = TextView(this).apply {
            setTextColor(0xFF7FFFBF.toInt()); textSize = 12f; text = "tap Board"
            maxWidth = (160 * dpx).toInt(); setPadding(0, (4 * dpx).toInt(), 0, 0)
        }
        debugTv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.MONOSPACE
            maxWidth = (230 * dpx).toInt(); visibility = View.GONE
            setPadding(0, (6 * dpx).toInt(), 0, 0)
        }
        boardBtn = chip("Board", 0xFF00C878.toInt()) { onBoardBtn() }
        boardBtn.setOnLongClickListener { startManual(); true }
        sideBtn = chip(sideLabel(), 0xFF2A2D36.toInt()) { v ->
            Prefs.setSide(this, (Prefs.side(this) + 1) % 3)
            v.text = sideLabel()
            reanalyze()
        }
        val toggle = chip("On", 0xFF2A2D36.toInt()) { v ->
            enabled = !enabled; v.text = if (enabled) "On" else "Off"
            if (!enabled) { dropArrow(); status("paused") } else reanalyze()
        }
        val copy = chip("Copy debug", 0xFF2A2D36.toInt()) {
            val cm = getSystemService(ClipboardManager::class.java)
            cm.setPrimaryClip(ClipData.newPlainText("chess-assist debug", debugText()))
            status("debug copied")
        }.apply { visibility = View.GONE }
        val debug = chip("Debug", 0xFF2A2D36.toInt()) {
            debugOn = !debugOn
            val v = if (debugOn) View.VISIBLE else View.GONE
            debugTv.visibility = v; copy.visibility = v
            if (debugOn) pushDebug()
        }
        val exit = chip("Exit", 0xFF3A1E22.toInt()) { stopSelf() }
        listOf(handle, statusTv, debugTv, boardBtn, sideBtn, toggle, debug, copy, exit).forEach { bar.addView(it) }

        barLp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, type,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 16; y = sh / 10
        }
        var sx = 0; var sy = 0; var rx = 0f; var ry = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = barLp.x; sy = barLp.y; rx = e.rawX; ry = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    barLp.x = sx + (e.rawX - rx).toInt(); barLp.y = sy + (e.rawY - ry).toInt()
                    wm.updateViewLayout(bar, barLp)
                }
            }
            true
        }
        add(bar, barLp)
    }

    private fun sideLabel() = when (Prefs.side(this)) { 1 -> "Side: White"; 2 -> "Side: Black"; else -> "Side: Auto" }

    private fun reanalyze() {
        analyzedFen = null; cachedMove = null; candidate = null
        dropArrow(); mode = Mode.CLEAN; cleanAfter = System.currentTimeMillis() + 150
    }

    private fun add(v: View, lp: LP) { wm.addView(v, lp); views += v }
    private fun remove(v: View) { runCatching { wm.removeView(v) }; views -= v }

    // ---------------- board setup ----------------
    /** Tap Board: find the board automatically. Long-press Board: place it by hand. */
    private fun onBoardBtn() {
        if (selector != null) { lockManual(); return }
        dropArrow(); boardReader = null
        status("finding board…")
        bg.post {
            val bmp = grab()
            if (bmp == null) { ui { status("no screen frames") }; return@post }
            val px = Pix(bmp)
            finishLock(px, BoardReader.find(px))
        }
    }

    private fun startManual() {
        if (selector != null) return
        dropArrow(); boardReader = null
        val s = FrameSelector(this)
        add(s, LP(LP.MATCH_PARENT, LP.MATCH_PARENT, type,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })
        remove(bar); add(bar, barLp)
        selector = s; boardBtn.text = "Lock"
        status("drag square over board")
    }

    private fun lockManual() {
        val sel = selector ?: return
        val rect = sel.screenRect()
        remove(sel); selector = null; boardBtn.text = "Board"
        status("reading…")
        bg.postDelayed({
            val bmp = grab() ?: run { ui { status("no screen frames") }; return@postDelayed }
            val px = Pix(bmp)
            finishLock(px, BoardReader.snap(px, rect))
        }, 400)
    }

    /** bg thread */
    private fun finishLock(px: Pix, rect: Rect) {
        val br = BoardReader.calibrate(px, rect)
        candidate = null; candCount = 0; analyzedFen = null; cachedMove = null
        mode = Mode.CLEAN; lastSig = null; pos = Pos.start()
        if (br == null) { ui { status("couldn't find board — long-press Board") }; return }
        val ok = br.occupancy(px).contentEquals(START_OCC)
        ui {
            arrow.gridRect = br.rect; arrow.move = null
            arrow.alpha = 1f; arrow.visibility = View.VISIBLE; arrow.invalidate()
            status(if (!ok) "board found, but not at start pos?" else if (br.flipped) "board locked (black side)" else "board locked (white side)")
            main.postDelayed({
                arrow.gridRect = null; arrow.visibility = View.GONE
                cleanAfter = System.currentTimeMillis() + 150
                boardReader = br
            }, 1200)
        }
    }

    // ---------------- arrow ----------------
    /** main thread */
    private fun showArrow() {
        val br = boardReader ?: return
        val mv = cachedMove ?: return
        if (mode == Mode.WATCH && arrow.move == mv && arrow.visibility == View.VISIBLE) return
        mask = ArrowMask.of(br.rect, mv, br.flipped)
        arrow.gridRect = null
        arrow.board = br.rect; arrow.flipped = br.flipped
        arrow.move = mv; arrow.eval = cachedEval
        arrow.alpha = 0f; arrow.visibility = View.VISIBLE; arrow.invalidate()
        arrow.animate().alpha(1f).setDuration(140).start()
        lastSig = null
        mode = Mode.WATCH
        lastSt = ""; status("$mv  $cachedEval")
    }

    /** main thread */
    private fun dropArrow() {
        arrow.animate().cancel()
        arrow.visibility = View.GONE
        mask = null
    }

    // ---------------- status / debug ----------------
    @Volatile private var lastSt = ""
    private fun st(s: String) { if (s != lastSt) { lastSt = s; ui { status(s) } } }
    private fun status(s: String) { statusTv.text = s }
    private fun ui(f: () -> Unit) { main.post(f) }

    private fun debugText(): String {
        val br = boardReader
        val sb = StringBuilder()
        sb.append("mode ${mode.name.lowercase()}  reads $reads\n")
        sb.append("board ${br?.rect?.toShortString() ?: "-"}  ${if (br?.flipped == true) "black-bottom" else "white-bottom"}\n")
        sb.append("side ${br?.let { mySide(it) } ?: "-"}  elo ${Prefs.elo(this)}  ${Prefs.moveTime(this)}ms\n")
        sb.append("engine $lastEngine\n")
        if (lastMsg.isNotEmpty()) sb.append("err $lastMsg\n")
        sb.append("fen $lastFen\n\n")
        sb.append("game:\n").append(pos.pretty())
        lastSeen?.let { sb.append("\n\nseen:\n").append(Tracker.prettyOcc(it)) }
        return sb.toString()
    }

    private fun pushDebug() {
        val t = debugText()
        ui { debugTv.text = t }
    }

    override fun onDestroy() {
        bg.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) views.toList().forEach { remove(it) }
        vd?.release(); reader?.close()
        projection?.stop(); projection = null
        engine?.close()
        bgThread.quitSafely()
        super.onDestroy()
    }
}
