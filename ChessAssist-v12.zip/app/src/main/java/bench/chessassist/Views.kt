package bench.chessassist

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/**
 * Shared arrow geometry (screen coordinates). Knight moves get an L-shaped arrow so they
 * don't look like a queen/bishop slide.
 */
class ArrowGeo(r: Rect, move: String, flipped: Boolean) {
    val s = r.width() / 8f
    val pts: List<PointF>
    val label: RectF

    init {
        fun c(sq: String): PointF {
            val f = sq[0] - 'a'; val rk = sq[1] - '1'
            val col = if (flipped) 7 - f else f
            val row = if (flipped) rk else 7 - rk
            return PointF(r.left + (col + 0.5f) * s, r.top + (row + 0.5f) * s)
        }
        val a = c(move.substring(0, 2)); val b = c(move.substring(2, 4))
        val df = abs(move[2] - move[0]); val dr = abs(move[3] - move[1])
        pts = if ((df == 1 && dr == 2) || (df == 2 && dr == 1)) {
            // long leg first, then the short one
            val corner = if (dr == 2) PointF(a.x, b.y) else PointF(b.x, a.y)
            listOf(a, corner, b)
        } else listOf(a, b)
        // small eval tag sitting on the piece's square (top edge)
        label = RectF(a.x - s * 0.42f, a.y - s * 0.5f + 2f, a.x + s * 0.42f, a.y - s * 0.5f + s * 0.28f)
    }
}

/** Screen area covered by the arrow + its label, so the board reader can ignore it. */
class ArrowMask(private val g: ArrowGeo) {
    private val hw = g.s * ArrowView.WIDTH / 2 + g.s * 0.06f
    private val hr = g.s * ArrowView.HEAD * 1.05f

    fun hits(x: Float, y: Float): Boolean {
        val b = g.pts.last()
        if (hypot(x - b.x, y - b.y) <= hr) return true
        if (g.label.contains(x, y)) return true
        for (i in 0 until g.pts.size - 1) {
            val p = g.pts[i]; val q = g.pts[i + 1]
            val dx = q.x - p.x; val dy = q.y - p.y
            val len2 = dx * dx + dy * dy
            val t = if (len2 == 0f) 0f else (((x - p.x) * dx + (y - p.y) * dy) / len2).coerceIn(0f, 1f)
            if (hypot(x - (p.x + t * dx), y - (p.y + t * dy)) <= hw) return true
        }
        return false
    }

    companion object {
        fun of(r: Rect, move: String, flipped: Boolean) = ArrowMask(ArrowGeo(r, move, flipped))
    }
}

/** Full-screen, non-touchable arrow layer. */
class ArrowView(ctx: Context) : View(ctx) {
    companion object { const val WIDTH = 0.14f; const val HEAD = 0.42f }
    var board: Rect? = null
    var flipped = false
    var move: String? = null
    var eval = ""
    var gridRect: Rect? = null
    private val gridPaint = Paint().apply { color = 0xCC00FF66.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f }

    private val loc = IntArray(2)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tagBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC000000.toInt() }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }

    override fun onDraw(c: Canvas) {
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat(); val oy = loc[1].toFloat()
        gridRect?.let { g ->
            val q = g.width() / 8f
            for (i in 0..8) {
                c.drawLine(g.left + i * q - ox, g.top - oy, g.left + i * q - ox, g.bottom - oy, gridPaint)
                c.drawLine(g.left - ox, g.top + i * q - oy, g.right - ox, g.top + i * q - oy, gridPaint)
            }
            return
        }
        val r = board ?: return
        val m = move ?: return
        if (m.length < 4) return
        val geo = ArrowGeo(r, m, flipped)
        val s = geo.s
        val color = Prefs.arrowColor(context)
        line.color = color; head.color = color
        line.strokeWidth = s * WIDTH

        val p = geo.pts.map { PointF(it.x - ox, it.y - oy) }
        val b = p.last(); val prev = p[p.size - 2]
        val ang = atan2(b.y - prev.y, b.x - prev.x)
        val hl = s * HEAD
        val path = Path().apply {
            moveTo(p[0].x, p[0].y)
            for (i in 1 until p.size - 1) lineTo(p[i].x, p[i].y)
            lineTo(b.x - cos(ang) * hl * 0.6f, b.y - sin(ang) * hl * 0.6f)
        }
        c.drawPath(path, line)
        c.drawPath(Path().apply {
            moveTo(b.x, b.y)
            lineTo(b.x - cos(ang - 0.5f) * hl, b.y - sin(ang - 0.5f) * hl)
            lineTo(b.x - cos(ang + 0.5f) * hl, b.y - sin(ang + 0.5f) * hl)
            close()
        }, head)

        // eval tag on the piece's own square
        if (eval.isNotEmpty()) {
            val t = RectF(geo.label.left - ox, geo.label.top - oy, geo.label.right - ox, geo.label.bottom - oy)
            c.drawRoundRect(t, t.height() / 2, t.height() / 2, tagBg)
            txt.textSize = t.height() * 0.72f
            c.drawText(eval, t.centerX(), t.centerY() - (txt.ascent() + txt.descent()) / 2, txt)
        }
    }
}

/** Movable / resizable square used to mark the board once. */
class FrameSelector(ctx: Context) : View(ctx) {
    private val r = RectF()
    private var mode = 0              // 0 none, 1 move, 2 resize
    private var lx = 0f; private var ly = 0f
    private val loc = IntArray(2)
    private val handleR = 36f

    private val dim = Paint().apply { color = 0x66000000 }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GREEN; style = Paint.Style.STROKE; strokeWidth = 4f }
    private val grid = Paint().apply { color = 0x8800FF00.toInt(); strokeWidth = 1.5f }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GREEN }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (r.isEmpty) {
            val s = w * 0.95f
            r.set((w - s) / 2, (h - s) / 2, (w + s) / 2, (h + s) / 2)
        }
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(0f, 0f, width.toFloat(), r.top, dim)
        c.drawRect(0f, r.bottom, width.toFloat(), height.toFloat(), dim)
        c.drawRect(0f, r.top, r.left, r.bottom, dim)
        c.drawRect(r.right, r.top, width.toFloat(), r.bottom, dim)
        val s = r.width() / 8
        for (i in 1..7) {
            c.drawLine(r.left + i * s, r.top, r.left + i * s, r.bottom, grid)
            c.drawLine(r.left, r.top + i * s, r.right, r.top + i * s, grid)
        }
        c.drawRect(r, edge)
        c.drawCircle(r.right, r.bottom, handleR, dot)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = when {
                    hypot(e.x - r.right, e.y - r.bottom) < handleR * 2 -> 2
                    r.contains(e.x, e.y) -> 1
                    else -> 0
                }
                lx = e.x; ly = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lx; val dy = e.y - ly
                if (mode == 1) r.offset(dx, dy)
                if (mode == 2) {
                    val size = max(80f, max(e.x - r.left, e.y - r.top))
                    r.right = r.left + size; r.bottom = r.top + size
                }
                lx = e.x; ly = e.y; invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }

    fun screenRect(): Rect {
        getLocationOnScreen(loc)
        return Rect(
            (r.left + loc[0]).roundToInt(), (r.top + loc[1]).roundToInt(),
            (r.right + loc[0]).roundToInt(), (r.bottom + loc[1]).roundToInt()
        )
    }
}

/** "DVD logo" style bouncing text; changes color on every wall hit. */
class Bouncer(ctx: Context, private val label: String) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 34f * d
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
    }
    private val colors = intArrayOf(
        0xFF00C878.toInt(), 0xFFFF5252.toInt(), 0xFF2196F3.toInt(),
        0xFFFFC107.toInt(), 0xFFE040FB.toInt(), 0xFF00E5FF.toInt()
    )
    private var ci = 0
    private var x = 20f * d; private var y = 20f * d
    private var vx = 2.2f * d; private var vy = 1.6f * d
    private var last = 0L

    private fun bump() { ci = (ci + 1) % colors.size }

    override fun onDraw(c: Canvas) {
        val now = android.os.SystemClock.uptimeMillis()
        val dt = if (last == 0L) 1f else ((now - last) / 16.67f).coerceIn(0f, 3f)
        last = now

        val w = p.measureText(label)
        val fm = p.fontMetrics
        val h = fm.descent - fm.ascent
        x += vx * dt; y += vy * dt
        if (x < 0) { x = 0f; vx = -vx; bump() }
        if (x + w > width) { x = width - w; vx = -vx; bump() }
        if (y < 0) { y = 0f; vy = -vy; bump() }
        if (y + h > height) { y = height - h; vy = -vy; bump() }

        val col = colors[ci]
        p.color = col
        p.setShadowLayer(14f * d, 0f, 0f, col)
        c.drawText(label, x, y - fm.ascent, p)
        postInvalidateOnAnimation()
    }
}
